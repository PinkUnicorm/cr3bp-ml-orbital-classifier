"""
app.py

Interactive Streamlit demo for the CR3BP orbital stability classifier.
"""

import joblib
import numpy as np
import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt

from cr3bp import make_features, integrate_orbit


st.set_page_config(
    page_title="CR3BP Orbital Stability Classifier",
    layout="wide"
)

st.title("Circular Restricted 3-Body Problem Orbital Stability Classifier")

st.markdown(
    """
    This app predicts whether a small object, such as a spacecraft or asteroid,
    will remain bounded, escape, or collide based on its initial conditions.
    """
)

# Load trained model and scaler
model = joblib.load("models/random_forest.pkl")
scaler = joblib.load("models/scaler.pkl")

label_names = {
    0: "Stable / Bounded",
    1: "Escape",
    2: "Collision"
}

st.sidebar.header("Initial Conditions")

st.sidebar.markdown(
    """
    Adjust the starting position and velocity of the small object.
    """
)

mu = st.sidebar.number_input(
    "Mass ratio μ",
    min_value=0.000001,
    max_value=0.5,
    value=0.01215,
    format="%.6f",
    help="Earth-Moon is approximately μ = 0.01215. CR3BP usually uses 0 < μ ≤ 0.5."
)

x0 = st.sidebar.slider(
    "Initial x-position",
    min_value=-1.5,
    max_value=1.5,
    value=0.5,
    step=0.01
)

y0 = st.sidebar.slider(
    "Initial y-position",
    min_value=-1.5,
    max_value=1.5,
    value=0.0,
    step=0.01
)

vx0 = st.sidebar.slider(
    "Initial x-velocity",
    min_value=-1.0,
    max_value=1.0,
    value=0.0,
    step=0.01
)

vy0 = st.sidebar.slider(
    "Initial y-velocity",
    min_value=-1.0,
    max_value=1.0,
    value=0.5,
    step=0.01
)

# Create feature vector
features = make_features(x0, y0, vx0, vy0, mu)
features_scaled = scaler.transform([features])

prediction = model.predict(features_scaled)[0]
probabilities = model.predict_proba(features_scaled)[0]

col1, col2 = st.columns(2)

with col1:
    st.subheader("Model Prediction")
    st.success(f"Predicted outcome: **{label_names[prediction]}**")

    probability_df = pd.DataFrame({
        "Outcome": [label_names[label] for label in model.classes_],
        "Probability": probabilities
    })

    st.subheader("Prediction Confidence")
    st.bar_chart(
        probability_df,
        x="Outcome",
        y="Probability"
    )

with col2:
    st.subheader("Selected Initial Condition")

    st.write(f"**Mass ratio μ:** {mu}")
    st.write(f"**Initial position:** ({x0:.2f}, {y0:.2f})")
    st.write(f"**Initial velocity:** ({vx0:.2f}, {vy0:.2f})")
    st.write(f"**Jacobi constant:** {features[5]:.4f}")

st.divider()

st.subheader("Numerically Integrated 2D Trajectory")

initial_state = [x0, y0, vx0, vy0]

solution = integrate_orbit(
    initial_state=initial_state,
    mu=mu,
    t_max=20.0,
    n_points=1000
)

x = solution.y[0]
y = solution.y[1]

fig, ax = plt.subplots(figsize=(8, 6))

ax.plot(x, y, linewidth=1.5, label="Trajectory")
ax.scatter(x0, y0, s=60, label="Start")

# Primary body locations in CR3BP coordinates
primary_1_x = -mu
primary_2_x = 1 - mu

ax.scatter(primary_1_x, 0, s=120, marker="o", label="Primary 1")
ax.scatter(primary_2_x, 0, s=80, marker="o", label="Primary 2")

ax.set_xlabel("x-position")
ax.set_ylabel("y-position")
ax.set_title("Simulated Orbit Trajectory")
ax.grid(True)
ax.axis("equal")
ax.legend()

st.pyplot(fig)